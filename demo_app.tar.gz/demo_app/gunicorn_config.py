# API Configuration
accesslog = '/opt/demo_app/demo_app.log'
loglevel = 'debug'
bind = '0.0.0.0:8882'
daemon = True
workers = 4
worker_class = 'uvicorn.workers.UvicornWorker'
threads = 2